Created by Script Tutorials
License (if not mentioned otherwise in the files): http://www.script-tutorials.com/terms-of-use/
